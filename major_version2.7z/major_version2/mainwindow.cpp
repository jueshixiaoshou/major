#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QProcess"
#include <Windows.h>
#include <QMouseEvent>
#include <QDebug>
void mouse_leftclick_fun(int x,int y,int dis_x,int dis_y);
QPoint plot[2];
int i=0;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
//    QTimer* timer;

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::mousePressEvent(QMouseEvent *event)//返回左键按下坐标事件
{
    if(event->button() == Qt::LeftButton)//左键
    {
//        qDebug()<<event->globalPos()<<endl;
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)//鼠标释放函数
{
//    qDebug()<<event->globalX();
//    qDebug()<<event->globalY();
    //nowmouseplace(event->globalX(),event->globalY());
    plot[i]=event->globalPos();
    qDebug()<<"第"<<i<<"个点是"<<plot[i];
    if((i==1&&((plot[1].y()-plot[0].y())<10))||i==0)
    {
        i=1-i;
    }
    else
    {
        plot[0]=plot[1];
        plot[1].isNull();
    }
}

void mouse_leftclick_fun(int x,int y,int dis_x,int dis_y)//左键单击函数
{
    mouse_event(MOUSEEVENTF_MOVE|MOUSEEVENTF_ABSOLUTE,x*65535/dis_x,y*65535/dis_y,0,0);
    mouse_event(MOUSEEVENTF_LEFTDOWN,0,0,0,0);
    Sleep(50);
    mouse_event(MOUSEEVENTF_LEFTUP,0,0,0,0);
}

void card_use(int num)//单击操作第x张牌
{
    mouse_event(MOUSEEVENTF_MOVE|MOUSEEVENTF_ABSOLUTE,(plot[0].x()+num*(plot[1].x()-plot[0].x()))*65535/1920,plot[0].y()*65535/1280,0,0);
    mouse_event(MOUSEEVENTF_LEFTDOWN,0,0,0,0);
    Sleep(50);
    mouse_event(MOUSEEVENTF_LEFTUP,0,0,0,0);
}
